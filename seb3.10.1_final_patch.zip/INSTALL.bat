@echo off
echo ================================================
echo   INSTALL SEB 3.10.1 FINAL PATCH
echo   - Bypass VM detection
echo   - Tampilan fullscreen normal (tanpa minimize)
echo   - Screenshot diizinkan
echo   - Taskbar SEB bawah muncul
echo   - Tombol browser (Chrome) aktif
echo   - Tombol Power/Shutdown di taskbar aktif
echo ================================================
echo.
echo Menyalin semua file ke Program Files...

set SRC=%~dp0
set DEST=C:\Program Files\SafeExamBrowser\Application\

copy /Y "%SRC%SafeExamBrowser.exe"                       "%DEST%"
copy /Y "%SRC%SafeExamBrowser.Client.exe"                "%DEST%"
copy /Y "%SRC%SafeExamBrowser.Configuration.dll"         "%DEST%"
copy /Y "%SRC%SafeExamBrowser.Monitoring.dll"            "%DEST%"
copy /Y "%SRC%SafeExamBrowser.UserInterface.Desktop.dll" "%DEST%"
copy /Y "%SRC%SafeExamBrowser.UserInterface.Mobile.dll"  "%DEST%"

if %errorlevel%==0 goto :INSTALL_SUCCESS
goto :INSTALL_FAILED

:INSTALL_SUCCESS
echo.
echo ================================================
echo   SUKSES! SEB Final Patch ter-install.
echo   Jalankan SEB seperti biasa.
echo ================================================
echo.
echo ================================================
echo   PENGATURAN JADWAL HAPUS CONFIGURATION OTOMATIS
echo ================================================
echo Folder target: C:\Program Files\SafeExamBrowser\Configuration\
echo.
set /p CONFIRM_SCH="Apakah Anda ingin membuat jadwal pembersihan otomatis? (Y/N): "
if /i "%CONFIRM_SCH%" neq "Y" goto :END_INSTALL

echo.
echo Pilih tipe penjadwalan:
echo [1] Harian (Daily)
echo [2] Mingguan (Weekly)
echo [3] Bulanan (Monthly)
echo [4] Satu Kali Saja (One-time Expiration)
echo.
set /p SCH_TYPE="Masukkan pilihan (1-4): "

if "%SCH_TYPE%"=="1" goto :SCH_DAILY
if "%SCH_TYPE%"=="2" goto :SCH_WEEKLY
if "%SCH_TYPE%"=="3" goto :SCH_MONTHLY
if "%SCH_TYPE%"=="4" goto :SCH_ONCE
echo Pilihan tidak valid.
goto :END_INSTALL

:SCH_DAILY
set /p DAYS_VAL="Dijalankan setiap berapa hari sekali? (contoh: 1 untuk tiap hari): "
schtasks /Create /TN "SEB_AutoCleanup_Config" /TR "cmd.exe /c rd /s /q \"C:\Program Files\SafeExamBrowser\Configuration\\\"" /SC DAILY /MO %DAYS_VAL% /RL HIGHEST /F
goto :SCH_DONE

:SCH_WEEKLY
set /p WEEKS_VAL="Dijalankan setiap berapa minggu sekali? (contoh: 1 untuk tiap minggu): "
schtasks /Create /TN "SEB_AutoCleanup_Config" /TR "cmd.exe /c rd /s /q \"C:\Program Files\SafeExamBrowser\Configuration\\\"" /SC WEEKLY /MO %WEEKS_VAL% /RL HIGHEST /F
goto :SCH_DONE

:SCH_MONTHLY
set /p MONTHS_VAL="Dijalankan setiap berapa bulan sekali? (contoh: 1 untuk tiap bulan): "
schtasks /Create /TN "SEB_AutoCleanup_Config" /TR "cmd.exe /c rd /s /q \"C:\Program Files\SafeExamBrowser\Configuration\\\"" /SC MONTHLY /MO %MONTHS_VAL% /RL HIGHEST /F
goto :SCH_DONE

:SCH_ONCE
set /p EXP_DAYS="Akan dihapus otomatis setelah berapa hari dari sekarang?: "
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d = (Get-Date).AddDays(%EXP_DAYS%).ToString('MM/dd/yyyy'); & schtasks.exe /Create /TN 'SEB_AutoCleanup_Config' /TR 'cmd.exe /c rd /s /q \"C:\Program Files\SafeExamBrowser\Configuration\\\"' /SC ONCE /SD $d /ST 12:00 /RL HIGHEST /F"
goto :SCH_DONE

:SCH_DONE
echo.
echo Penjadwalan selesai diproses.
goto :END_INSTALL

:INSTALL_FAILED
echo.
echo GAGAL! Pastikan Run as Administrator.
goto :END_INSTALL

:END_INSTALL
echo.
pause

