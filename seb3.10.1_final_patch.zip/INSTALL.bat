@echo off
echo ================================================
echo   INSTALL SEB 3.10.1 FINAL PATCH
echo   - Bypass VM detection
echo   - Tampilan fullscreen normal (tanpa minimize)
echo   - Screenshot diizinkan
echo   - Taskbar SEB bawah muncul
echo   - Tombol browser (Chrome) aktif
echo   - Tombol Power/Shutdown di taskbar aktif
echo ================================================
echo.
echo Menyalin semua file ke Program Files...

set SRC=%~dp0
set DEST=C:\Program Files\SafeExamBrowser\Application\

copy /Y "%SRC%SafeExamBrowser.exe"                       "%DEST%"
copy /Y "%SRC%SafeExamBrowser.Client.exe"                "%DEST%"
copy /Y "%SRC%SafeExamBrowser.Configuration.dll"         "%DEST%"
copy /Y "%SRC%SafeExamBrowser.Monitoring.dll"            "%DEST%"
copy /Y "%SRC%SafeExamBrowser.UserInterface.Desktop.dll" "%DEST%"
copy /Y "%SRC%SafeExamBrowser.UserInterface.Mobile.dll"  "%DEST%"

if %errorlevel%==0 (
    echo.
    echo ================================================
    echo   SUKSES! SEB Final Patch ter-install.
    echo   Jalankan SEB seperti biasa.
    echo ================================================
) else (
    echo.
    echo GAGAL! Pastikan Run as Administrator.
)
echo.
pause
